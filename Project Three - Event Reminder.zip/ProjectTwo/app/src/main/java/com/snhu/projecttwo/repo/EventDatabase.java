package com.snhu.projecttwo.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.snhu.projecttwo.model.Event;
import com.snhu.projecttwo.model.User;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class EventDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "events.db";
    // Table name variable
    private static final String TABLE_NAME = "events";

    // ID column variable
    private static final String ID_COL = "id";

    // Event name column variable
    private static final String EVENT_NAME = "event";

    // below variable id for our course duration column.
    private static final String DATE = "date";
    private static final String USER_NAME = "username";
    private static EventDatabase _eventDB;

    public EventDatabase(Context context) {super(context, DATABASE_NAME, null, VERSION);}

    public static EventDatabase getInstance(Context context) {
        if (_eventDB == null) {
            _eventDB = new EventDatabase(context);
        }
        return _eventDB;
    }

    @Override
    public void onCreate(SQLiteDatabase _db) {
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + EVENT_NAME + " TEXT,"
                + DATE + " TEXT,"
                + USER_NAME + " TEXT)";

        // at last we are calling a exec sql
        // method to execute above sql query
        _db.execSQL(query);
    }

    public Boolean addEvent(Event event, User user){
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values= new ContentValues();

        values.put("username", user.getUserName());
        values.put("date", event.getDate());
        values.put("event", event.getEvent());

        long id = _db.insert(TABLE_NAME, null, values);
        return id != -1;
    }

    public void removeEvent(Integer entryID){
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("events","_id = ?",new String[]{String.valueOf(entryID)});
    }

    public Boolean updateEvent(int _id, String event, User _user){
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values= new ContentValues();

        values.put("username", _user.getUserName());
        values.put("event", event);

        long id = _db.update("events", values, "_id = " + _id, null);
        return id != -1;
    }
    public ArrayList<Event> listEvents(User _user) throws ParseException {

        SQLiteDatabase _db = this.getWritableDatabase();

        Cursor cursor = _db.rawQuery("SELECT * FROM events ORDER BY date", null);

        ArrayList<Event> eventArrayList = new ArrayList<>();

        if(cursor.moveToFirst()){
            do {
                //get the username from the db entry
                String username = cursor.getString(1);

                //if the username matches the user logged in then start the loop
                if (username.equals(_user.getUserName())){

                    int ID = cursor.getInt(0);
                    String date = cursor.getString(2);

                    //change the date from ISO to mm-dd-yyyy
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date newDate = null;
                    String prettyDate = null;
                    try {
                        newDate = format.parse(date);
                        format = new SimpleDateFormat("MM-dd-YYYY");
                        prettyDate = format.format(newDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    String userEvent = cursor.getString(3);

                    //use the constructor to make objects
                    //add the objects to the list
                    Event newEntry = new Event(ID, prettyDate, userEvent);
                    eventArrayList.add(newEntry);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return eventArrayList;
    }

    public void deleteUser(User _user){
        SQLiteDatabase _db = this.getWritableDatabase();

        _db.delete("events", "username = ?", new String[]{_user.getUserName()} );
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}

