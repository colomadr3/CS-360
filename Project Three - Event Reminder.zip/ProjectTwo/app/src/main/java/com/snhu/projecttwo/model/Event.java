package com.snhu.projecttwo.model;

import androidx.annotation.NonNull;

public class Event {
    // Declare Variables
    private int Id;
    private String date;
    private String event;

    // Event object Constructor
    public Event(int Id, String date, String event) {
        this.Id = Id;
        this.date = date;
        this.event = event;
    }

    // Overload Constructor
    public Event(@NonNull String date, String event){
        this.date = date;
        this.event = event;
    }

    // Mutators and Accessor for Object attributes: ID, Date, and Event
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }
}
