package com.snhu.projecttwo.model;
import android.content.Context;

// Class to initialize user object
public class User {

    private String userName;
    private String event = "No Events"; // initialize new users' events
    private boolean textPermission = false;
    private String SMSText = "0000000000";
    private static User _loggedUser;

    // Prevents app from having multiple users logged in
    public static User getUserInstance(){
        if(_loggedUser == null){
            _loggedUser = new User();
        }
        return _loggedUser;
    }

    private User(){}

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getEvent() {
        return event;
    }
    public void setEvent(String event) {
        this.event = event;
    }
    public boolean isTextPermission() {return textPermission;}
    public void setTextPermission(boolean textPermission) {
        this.textPermission = textPermission;
    }

    public String getSMSText() {
        return SMSText;
    }

    public void setSMSText(String SMSText) {
        this.SMSText = SMSText;
    }
}
