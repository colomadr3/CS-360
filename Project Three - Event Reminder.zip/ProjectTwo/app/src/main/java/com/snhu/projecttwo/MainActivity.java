package com.snhu.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.util.ArrayList;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.snhu.projecttwo.model.Event;
import com.snhu.projecttwo.model.User;
import com.snhu.projecttwo.repo.EventDatabase;
import com.snhu.projecttwo.viewmodel.EventListViewModel;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Event> eventArrayList;
    private EventDatabase _eventDB;
    private EventListViewModel eventListViewModel;
    private RecyclerView eventRV;
    private FloatingActionButton eventButton;
    private User user;

    private final static String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing our all variables.
        eventArrayList = new ArrayList<>();
        _eventDB = new EventDatabase(MainActivity.this);
        user = User.getUserInstance();

        // getting our course array
        // list from db handler class.
        try {
            eventArrayList = _eventDB.listEvents(user);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        // on below line passing our array list to our adapter class.
        eventListViewModel = new EventListViewModel(eventArrayList, MainActivity.this);
        eventRV = findViewById(R.id.eventRecyclerView);

        // setting layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false);
        eventRV.setLayoutManager(linearLayoutManager);

        // setting our adapter to recycler view.
        eventRV.setAdapter(eventListViewModel);

        eventButton = findViewById(R.id.addButton);
        eventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EventEditActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.event_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if (item.getItemId() == R.id.settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}