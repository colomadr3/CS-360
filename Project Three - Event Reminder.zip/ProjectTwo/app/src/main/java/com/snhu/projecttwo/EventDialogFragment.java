package com.snhu.projecttwo;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
public class EventDialogFragment extends DialogFragment {

    public interface NotificationSwitchListener {
        void NotificationSwitchListener(int which);
    }

    private NotificationSwitchListener mListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new AlertDialog.Builder(requireActivity())
                .setTitle(R.string.eventNotification)
                .setMessage(R.string.permissionRequest)
                .setPositiveButton(R.string.positiveButton, (dialog, id) -> {
                    // User clicked Yes
                })
                .setNegativeButton(R.string.negativeButton, (dialog, id) -> {
                    // User clicked No
                })
                .create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (NotificationSwitchListener) context;
    }
}