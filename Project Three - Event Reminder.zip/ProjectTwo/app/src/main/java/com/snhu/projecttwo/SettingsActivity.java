package com.snhu.projecttwo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

import com.snhu.projecttwo.model.User;
import com.snhu.projecttwo.repo.EventDatabase;
import com.snhu.projecttwo.repo.UserDatabase;

public class SettingsActivity extends AppCompatActivity {

    private CompoundButton notificationSwitch;
    private EditText userPhone;
    private Button deleteAccount;
    private UserDatabase _userDB;
    private EventDatabase _eventDB;
    private User user;
    public EditText phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        user = User.getUserInstance();
        phone = findViewById(R.id.editTextPhone);
        phone.setText(user.getSMSText());

        deleteAccount = findViewById(R.id.deleteAccounts);
        notificationSwitch = findViewById(R.id.notifications);
        notificationSwitch.setChecked(user.isTextPermission());
        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                android.app.AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                builder
                        .setTitle(R.string.eventNotification)
                        .setMessage(R.string.permissionRequest)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(R.string.positiveButton, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                user.setTextPermission(isChecked);
                            }
                        })
                        .setNegativeButton(R.string.negativeButton,  new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                notificationSwitch.setOnCheckedChangeListener (null);
                                notificationSwitch.setChecked(false);
                                user.setTextPermission(isChecked);
                            }
                        })
                        .show();

            }
        });
    }
    public void deleteUserAccounts(View view){
        //call the singleton
        _userDB = UserDatabase.getInstance(this);
        _eventDB = EventDatabase.getInstance(this);
        user = User.getUserInstance();

        _eventDB.deleteUser(user);
        _userDB.deleteUser(user);

        //force the user back out
        this.finishAffinity();
        System.exit(0);
    }
    public void openMain(View view){

        phone = findViewById(R.id.editTextPhone);
        String phoneNum = phone.getText().toString();

        if(phoneNum != null){
            user.setSMSText(phoneNum);
        }

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}