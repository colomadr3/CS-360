package com.snhu.projecttwo.viewmodel;

import static com.snhu.projecttwo.MainActivity.*;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.snhu.projecttwo.EventEditActivity;
import com.snhu.projecttwo.MainActivity;
import com.snhu.projecttwo.R;
import com.snhu.projecttwo.model.Event;
import com.snhu.projecttwo.repo.EventDatabase;
import com.snhu.projecttwo.repo.UserDatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.util.ArrayList;
import android.util.Log;

public class EventListViewModel extends RecyclerView.Adapter<EventListViewModel.ViewHolder> {

    //private EventDatabase _eventDB;
    private ArrayList<Event> eventArrayList;
    private UserDatabase _userDB;
    private Context context;
    private RecyclerView eventRV;

    // constructor
    public EventListViewModel(ArrayList<Event> eventArrayList, Context context) {
        this.eventArrayList = eventArrayList;
        this.context = context;
    }
    public EventListViewModel(Application application) {
        //_eventDB = EventDatabase.getInstance(application.getApplicationContext());
    }

    @NonNull
    @Override
    public EventListViewModel.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout
        // file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_items, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventListViewModel.ViewHolder holder, int position) {
        // on below line we are setting data
        // to our views of recycler view item.
        Event event = eventArrayList.get(position);
        holder.eventName.setText(event.getEvent());
        holder.eventDate.setText(event.getDate());
        holder.eventItem = event;
    }

    @Override
    public int getItemCount() {
        return eventArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        // creating variables for our text views.
        private TextView eventName, eventDate;
        private ImageButton deleteEvent, editEvent;
        private Event eventItem;
        private EventDatabase _eventDB = new EventDatabase(context);

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            eventName = itemView.findViewById(R.id.eventNameRV);
            eventDate = itemView.findViewById(R.id.eventDateRV);

            editEvent = itemView.findViewById(R.id.editButton);
            editEvent.setOnClickListener(v -> {
                    Intent intent = new Intent(context, EventEditActivity.class);
                    intent.putExtra("event_date",eventItem.getDate());
                    intent.putExtra("event_id", eventItem.getId());
                    intent.putExtra("event_user",eventItem.getUsername());
                    context.startActivity(intent);
            });

            deleteEvent = itemView.findViewById(R.id.deleteButton);
            deleteEvent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    _eventDB.removeEvent(eventItem.getId());
                    try {
                        refreshRV();
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        }
    }
}