package com.snhu.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import com.snhu.projecttwo.repo.EventDatabase;
import com.snhu.projecttwo.repo.UserDatabase;
import com.snhu.projecttwo.model.User;

public class LoginActivity extends AppCompatActivity {
    // Declared Variables
    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private UserDatabase _userDB;
    private User userLogin;
    private EventDatabase _eventsDB;


    private void userLogin(View view, String _user){

        // open event table
        _eventsDB = EventDatabase.getInstance(this);

        // instantiate the User object
        userLogin = User.getUserInstance();
        userLogin.setUserName(_user);

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameInput = findViewById(R.id.username_field);
        passwordInput = findViewById(R.id.password_field);
        loginButton = findViewById(R.id.login_button);
        _userDB = UserDatabase.getInstance(this);

        usernameInput.addTextChangedListener(loginTextWatcher);
        passwordInput.addTextChangedListener(loginTextWatcher);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userName = usernameInput.getText().toString();
                String passWord = passwordInput.getText().toString();
                boolean validUser = _userDB.checkUserName(userName);
                boolean validPass = _userDB.checkUserPassword(userName, passWord);

                //first test if a valid user/pass combo --> registered user
                if(validUser){
                    if(validPass){
                        Toast.makeText(LoginActivity.this,R.string.success,Toast.LENGTH_SHORT).show();
                        userLogin(v, userName);
                    }
                    else{
                        Toast.makeText(LoginActivity.this,R.string.incorrectPW,Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                    builder
                            .setTitle(R.string.newAccount)
                            .setMessage(R.string.accountRegister)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton(R.string.positiveButton, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    //Yes button clicked, do something
                                    //get the userDB
                                    //call insert user
                                    Boolean userAdded = _userDB.addUser(userName, passWord);

                                    if(userAdded){
                                        Toast.makeText(LoginActivity.this,R.string.added,Toast.LENGTH_SHORT).show();
                                        userLogin(v, userName);
                                    }
                                    else{
                                        Toast.makeText(LoginActivity.this,R.string.failed,Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton(R.string.negativeButton, null) //Do nothing on no
                            .show();
                }

            }
        });

    }

    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String userName = usernameInput.getText().toString().trim();
            String passWord = passwordInput.getText().toString().trim();

            loginButton.setEnabled(!userName.isEmpty() && !passWord.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

}