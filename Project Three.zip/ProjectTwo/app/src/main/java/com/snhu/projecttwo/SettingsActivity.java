package com.snhu.projecttwo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.widget.CompoundButtonCompat;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

import com.snhu.projecttwo.model.User;
import com.snhu.projecttwo.repo.EventDatabase;
import com.snhu.projecttwo.repo.UserDatabase;

public class SettingsActivity extends AppCompatActivity {

    private CompoundButton notificationSwitch;
    private Button deleteAccount;
    private UserDatabase _userDB;
    private EventDatabase _eventDB;
    private User user;
    public EditText phone;
    public boolean userNotify;
    public int notify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        _userDB = UserDatabase.getInstance(this);
        user = User.getUserInstance();
        phone = findViewById(R.id.editTextPhone);
        phone.setText(user.getSMSText());
        userNotify = user.isTextPermission();
        Log.d("SettingActivity", "userNotify is " + userNotify);
        Log.d("SettingActivity", "user info: " + user);
        String userName = user.getUserName();

        deleteAccount = findViewById(R.id.deleteAccounts);
        notificationSwitch = findViewById(R.id.notifications);
        notificationSwitch.setChecked(user.isTextPermission());

        if (!userNotify){
            notificationSwitch.setChecked(false);
        }

        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                notificationSwitch.setOnCheckedChangeListener(this);
                if(isChecked) {
                    android.app.AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                    builder
                            .setTitle(R.string.eventNotification)
                            .setMessage(R.string.permissionRequest)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton(R.string.positiveButton, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    user.setTextPermission(true);
                                    notify = 1;
                                    Log.d("notification switch", "Switch is on");
                                    _userDB.updateNotify(userName, notify);
                                }
                            })
                            .setNegativeButton(R.string.negativeButton, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // reset button to previous state.
                                    notificationSwitch.setChecked(false);
                                    user.setTextPermission(false);
                                    notify = 0;
                                    Log.d("notification switch", "Switch is off");
                                    _userDB.updateNotify(userName, notify);
                                }
                            })
                            .show();
                }
                else{
                    notificationSwitch.setChecked(false);
                    user.setTextPermission(false);
                    Log.d("notification switch", "Switch is off");
                }
            }
        });

    }
    public void deleteUserAccounts(View view){
        //call the singleton
        _userDB = UserDatabase.getInstance(this);
        _eventDB = EventDatabase.getInstance(this);
        user = User.getUserInstance();

        _eventDB.deleteUser(user);
        _userDB.deleteUser(user);

        //force the user back out
        this.finishAffinity();
        System.exit(0);
    }

    public void saveSettings(View view){

        phone = findViewById(R.id.editTextPhone);
        _userDB = UserDatabase.getInstance(this);
        user = User.getUserInstance();
        String userName = user.getUserName();
        String phoneNum = phone.getText().toString();

        if(phoneNum != null){
            user.setSMSText(phoneNum);
            _userDB.updatePhone(userName, phoneNum);
        }

        Intent intent = new Intent(view.getContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }
}