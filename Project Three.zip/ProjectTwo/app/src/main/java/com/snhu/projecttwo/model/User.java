package com.snhu.projecttwo.model;
import android.content.Context;

// Class to initialize user object
public class User {

    // Declare attribute variables
    private String userName;
    private String passWord;
    private boolean textPermission = false;
    private String SMSText = null;
    private static User _loggedUser;

    // Constructor
    private User(){}
    private User(String userName, String passWord, boolean textPermission,String SMSText) {
        this.userName = userName;
        this.passWord = passWord;
        this.textPermission = textPermission;
        this.SMSText = SMSText;
    }
    // Prevents app from having multiple users logged in
    public static User getUserInstance(){
        if(_loggedUser == null){
            _loggedUser = new User();
        }
        return _loggedUser;
    }

    // Mutator and accessor methods for user attributes
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserName() {
        return userName;
    }

    public void setTextPermission(boolean textPermission) {
        this.textPermission = textPermission;
    }
    public boolean isTextPermission() {return textPermission;}

    public void setSMSText(String SMSText) {
        this.SMSText = SMSText;
    }
    public String getSMSText() {
        return SMSText;
    }

}
