package com.snhu.projecttwo.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.snhu.projecttwo.model.User;

public class UserDatabase extends SQLiteOpenHelper {

    // Declare database constants
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;
    private static  final String TABLE_NAME = "accounts";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String NOTIFICATIONS = "notifications";
    private static final String PHONE = "phone";


    private static UserDatabase _UserDB;

    // Constructor for the user database class
    private UserDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }


    public static UserDatabase getInstance(Context context) {
        if (_UserDB == null) {
            _UserDB = new UserDatabase(context);
        }
        return _UserDB;
    }

    // Create users table with the username set as the primary key for each entry
    @Override
    public void onCreate(SQLiteDatabase _db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + USERNAME + " TEXT PRIMARY KEY, "
                + PASSWORD + " TEXT, "
                + NOTIFICATIONS + " NUMERIC, "
                + PHONE + " TEXT)";
        _db.execSQL(query);
    }

    // Checks to see if the table already exists
    @Override
    public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
        _db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(_db);
    }

    // Adds a new user
    public boolean addUser(String userName, String password){
        // creating a variable for the sqlite database to write to
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values= new ContentValues();

        // assigning values to table columns
        values.put(USERNAME, userName);
        values.put(PASSWORD, password);
        values.put(NOTIFICATIONS, 0);
        values.put(PHONE, "");

        // values inserted to table
        long writeResult = _db.insert(TABLE_NAME, null, values);

        // close database after adding user
        _db.close();

        //check if the write result is successful
        return (writeResult == -1) ? false : true;
    }

    public void updatePhone(String userName, String phoneNum){
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values= new ContentValues();

        values.put(USERNAME, userName);
        values.put(PHONE, phoneNum);
        Log.d("UserDatabase", "What is added " + values.valueSet());
        Log.d("UserDatabase", "column search " + userName);
        _db.update(TABLE_NAME, values, "username=?", new String[]{userName});
        _db.close();
    }
    public void updateNotify(String userName, int notify){
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put(USERNAME, userName);
        values.put(NOTIFICATIONS, notify);
        Log.d("UserDatabase", "What is added " + values.valueSet());
        _db.update(TABLE_NAME, values, "username=?", new String[]{userName});
        _db.close();
    }

    // Check if username exists - return true or false
    public Boolean checkUserName(String userName){
        SQLiteDatabase _db = this.getWritableDatabase();
        Cursor cursor = _db.rawQuery("Select * from " + TABLE_NAME + " where username = ?",
                new String[]{userName});
        return (cursor.getCount() > 0) ? true : false;
    }

    // Check the password is correct in relation to username - return true or false
    public Boolean checkUserPassword(String userName, String password){
        SQLiteDatabase _db = this.getWritableDatabase();
        Cursor cursor = _db.rawQuery("Select * from " + TABLE_NAME + " where username = ? and password = ?",
                new String[]{userName, password});
        return (cursor.getCount() > 0) ? true : false;
    }

    // Delete all users from database
    public void deleteUser(User _user){
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete(TABLE_NAME, "username = ?", new String[]{_user.getUserName()} );
    }
}
