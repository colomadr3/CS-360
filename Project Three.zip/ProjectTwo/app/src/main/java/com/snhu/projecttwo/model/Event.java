package com.snhu.projecttwo.model;

import androidx.annotation.NonNull;

public class Event {
    // Declare Variables
    private int Id;
    private String date;
    private String event;
    private String username;

    // Event object Constructor
    public Event(int Id, String date, String event, String username) {
        this.Id = Id;
        this.date = date;
        this.event = event;
        this.username = username;
    }

    // Overload Constructor
    public Event(@NonNull String date, String event, String username){
        this.date = date;
        this.event = event;
        this.username = username;
    }

    // Mutators and Accessor for Object attributes: ID, Date, and Event
    public void setId(int Id) {
        this.Id = Id;
    }
    public int getId() {
        return Id;
    }

    public void setDate(String date) {
        this.date = date;
    }
    public String getDate() {
        return date;
    }

    public void setEvent(String event) {
        this.event = event;
    }
    public String getEvent() {
        return event;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getUsername() {
        return username;
    }

}
