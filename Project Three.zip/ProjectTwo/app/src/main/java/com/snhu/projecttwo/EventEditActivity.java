package com.snhu.projecttwo;

import static com.snhu.projecttwo.MainActivity.refreshRV;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.snhu.projecttwo.model.User;
import com.snhu.projecttwo.model.Event;
import com.snhu.projecttwo.repo.EventDatabase;

import java.text.ParseException;
import java.util.Calendar;

public class EventEditActivity extends AppCompatActivity {

    // on below line we are creating variables.
    private Button dateButton;
    private Button saveButton;
    private Button cancelButton;
    private TextView dateSelection;
    private String dateString;
    private User user;
    private EventDatabase _eventDB;
    private EditText userEvent;

    public void openMainForm(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);

        // on below line we are initializing our variables.
        dateButton = findViewById(R.id.pickDateButton);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        dateSelection = findViewById(R.id.selectedDate);
        userEvent = findViewById(R.id.userEvent);

        user = User.getUserInstance();
        _eventDB = EventDatabase.getInstance(this);

        if (getIntent().getStringExtra("event_date") != null){
            dateSelection.setText(getIntent().getStringExtra("event_date"));
        }

        // on click listener for pick date button
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Initialize variable with calendar instance
                final Calendar c = Calendar.getInstance();

                // on below line we are getting
                // our day, month and year.
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                // on below line we are creating a variable for date picker dialog.
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        // on below line we are passing context.
                        EventEditActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // on below line we are setting date to our text view.
                                dateSelection.setText((monthOfYear + 1) + "-" + dayOfMonth + "-" + year);
                                dateString = String.valueOf(year) + "-" + String.valueOf(monthOfYear + 1) + "-" + String.valueOf(dayOfMonth);

                            }
                        },
                        // on below line we are passing year,
                        // month and day for selected date in our date picker.
                        year, month, day);
                // at last we are calling show to
                // display our date picker dialog.
                datePickerDialog.show();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dateSelection.getText().toString();
                String eventItem = userEvent.getText().toString();
                String loggedUser = String.valueOf(user.getUserName());
                int eventID = getIntent().getIntExtra("event_id", -1);

                //protect against an empty form
                if (!date.equals("") && !eventItem.equals("")){
                    Event eventObj = new Event(dateString, eventItem, loggedUser);
                    if (getIntent().getStringExtra("event_date") != dateSelection.getText()){
                        Boolean addEvent = _eventDB.addEvent(eventObj);
                        if(addEvent){
                            Toast.makeText(EventEditActivity.this,R.string.eventAdded,Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(EventEditActivity.this,R.string.eventFailed,Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Boolean updateEvent = _eventDB.updateEvent(eventID, eventItem, loggedUser);
                        if(updateEvent){
                            Toast.makeText(EventEditActivity.this,R.string.eventUpdated,Toast.LENGTH_SHORT).show();
                            try {
                                refreshRV();
                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        else{
                            Toast.makeText(EventEditActivity.this,R.string.eventFailed,Toast.LENGTH_SHORT).show();
                        }
                    }

                }

                //go back to main and refresh recyclerview
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go back to main
                finish();
            }
        });
    }
}